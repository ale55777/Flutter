class Workout {
  final String id;
  String title;
  String description;
  String difficulty;
  int duration; // in minutes

  Workout({
    required this.id,
    required this.title,
    required this.description,
    required this.difficulty,
    required this.duration,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'difficulty': difficulty,
      'duration': duration,
    };
  }

  static Workout fromMap(Map<String, dynamic> map) {
    return Workout(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      difficulty: map['difficulty'],
      duration: map['duration'],
    );
  }
}
