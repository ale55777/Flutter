import 'package:flutter/material.dart';
import 'dart:math';

class BMICalculatorScreen extends StatefulWidget {
  @override
  _BMICalculatorScreenState createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen>
    with SingleTickerProviderStateMixin {
  bool isMale = true;
  double height = 170;
  int weight = 60;
  int age = 20;

  late AnimationController _controller;
  late Animation<double> _fadeIn;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(duration: Duration(milliseconds: 800), vsync: this);
    _fadeIn = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void calculateBMI() {
    double bmi = weight / pow(height / 100, 2);
    String category = '';
    String interpretation = '';

    if (bmi < 18.5) {
      category = 'Underweight';
      interpretation = 'You should eat more nutritious food!';
    } else if (bmi < 25) {
      category = 'Normal';
      interpretation = 'Great job! Keep it up.';
    } else if (bmi < 30) {
      category = 'Overweight';
      interpretation = 'Try exercising a bit more.';
    } else {
      category = 'Obese';
      interpretation = 'Consider consulting a nutritionist.';
    }

    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => BMIResultScreen(
          bmi: bmi,
          category: category,
          interpretation: interpretation,
        ),
        transitionsBuilder: (_, animation, __, child) {
          return SlideTransition(
            position: Tween(begin: Offset(1, 0), end: Offset.zero)
                .animate(animation),
            child: FadeTransition(opacity: animation, child: child),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        title: Text('BMI Calculator'),
        backgroundColor: Colors.yellow,
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: FadeTransition(
          opacity: _fadeIn,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Gender Selector
                  Row(
                    children: [
                      _genderCard(Icons.male, 'Male', true),
                      SizedBox(width: 10),
                      _genderCard(Icons.female, 'Female', false),
                    ],
                  ),
                  SizedBox(height: 20),

                  // Height Slider
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: _boxDecoration(),
                    child: Column(
                      children: [
                        Text('Height', style: TextStyle(fontSize: 18)),
                        Text('${height.round()} cm',
                            style: TextStyle(
                                fontSize: 26, fontWeight: FontWeight.bold)),
                        Slider(
                          value: height,
                          min: 100,
                          max: 220,
                          divisions: 120,
                          activeColor: Colors.deepPurple,
                          label: height.round().toString(),
                          onChanged: (val) {
                            setState(() => height = val);
                          },
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 20),

                  // Weight & Age
                  Row(
                    children: [
                      _counterCard('Weight', weight, () {
                        setState(() => weight++);
                      }, () {
                        if (weight > 1) setState(() => weight--);
                      }),
                      SizedBox(width: 10),
                      _counterCard('Age', age, () {
                        setState(() => age++);
                      }, () {
                        if (age > 1) setState(() => age--);
                      }),
                    ],
                  ),
                  SizedBox(height: 30),

                  // Calculate Button
                  ElevatedButton(
                    onPressed: calculateBMI,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.yellow,
                      padding:
                      EdgeInsets.symmetric(horizontal: 50, vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text('Calculate',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _genderCard(IconData icon, String label, bool male) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => isMale = male);
        },
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: isMale == male ? Colors.deepPurple : Colors.grey[300],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon,
                  size: 30,
                  color: isMale == male ? Colors.white : Colors.black),
              SizedBox(height: 6),
              Text(label,
                  style: TextStyle(
                      color: isMale == male ? Colors.white : Colors.black)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _counterCard(String title, int value, VoidCallback increment,
      VoidCallback decrement) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: _boxDecoration(),
        child: Column(
          children: [
            Text(title, style: TextStyle(fontSize: 18)),
            Text('$value',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: decrement,
                  icon: Icon(Icons.remove_circle_outline),
                ),
                IconButton(
                  onPressed: increment,
                  icon: Icon(Icons.add_circle_outline),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      color: Colors.grey[200],
      borderRadius: BorderRadius.circular(12),
      boxShadow: [
        BoxShadow(
            color: Colors.grey.shade300, blurRadius: 6, offset: Offset(2, 2))
      ],
    );
  }
}

class BMIResultScreen extends StatelessWidget {
  final double bmi;
  final String category;
  final String interpretation;

  BMIResultScreen({
    required this.bmi,
    required this.category,
    required this.interpretation,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Result'),
        backgroundColor: Colors.yellow,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Card(
            elevation: 8,
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Your BMI', style: TextStyle(fontSize: 22)),
                  Text(
                    bmi.toStringAsFixed(1),
                    style: TextStyle(
                      fontSize: 48,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurple,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    category,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.orange,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    interpretation,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
