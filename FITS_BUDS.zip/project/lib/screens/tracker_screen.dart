import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Workout {
  final String name;
  final int durationSeconds;
  final int calories;
  bool isCompleted;

  Workout({
    required this.name,
    required this.durationSeconds,
    required this.calories,
    this.isCompleted = false,
  });
}

class TrackerScreen extends StatefulWidget {
  @override
  _TrackerScreenState createState() => _TrackerScreenState();
}

class _TrackerScreenState extends State<TrackerScreen> {
  List<Workout> workouts = [
    Workout(name: 'Push Ups', durationSeconds: 10, calories: 30),
    Workout(name: 'Squats', durationSeconds: 20, calories: 40),
    Workout(name: 'Jumping Jacks', durationSeconds: 15, calories: 25),
  ];

  Map<String, int> remainingTime = {};
  Map<String, Timer?> timers = {};

  int stopwatchSeconds = 0;
  Timer? stopwatchTimer;
  bool isStopwatchRunning = false;

  @override
  void initState() {
    super.initState();
    _loadProgress();
    for (var workout in workouts) {
      remainingTime[workout.name] = workout.durationSeconds;
    }
  }

  @override
  void dispose() {
    stopwatchTimer?.cancel();
    timers.forEach((key, timer) => timer?.cancel());
    super.dispose();
  }

  void _loadProgress() async {
    final prefs = await SharedPreferences.getInstance();
    for (var workout in workouts) {
      bool completed = prefs.getBool(workout.name) ?? false;
      setState(() {
        workout.isCompleted = completed;
      });
    }
  }

  void _saveProgress() async {
    final prefs = await SharedPreferences.getInstance();
    for (var workout in workouts) {
      prefs.setBool(workout.name, workout.isCompleted);
    }
  }

  void _startWorkoutTimer(Workout workout) {
    final name = workout.name;
    timers[name]?.cancel();
    remainingTime[name] = workout.durationSeconds;

    timers[name] = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (remainingTime[name]! > 0) {
          remainingTime[name] = remainingTime[name]! - 1;
        } else {
          timer.cancel();
          workout.isCompleted = true;
          _saveProgress();
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('${workout.name} completed! Calories burned: ${workout.calories}'),
          ));
        }
      });
    });
  }

  String formatTime(int seconds) {
    final hours = seconds ~/ 3600;
    final minutes = (seconds % 3600) ~/ 60;
    final secs = seconds % 60;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  void startStopwatch() {
    stopwatchTimer = Timer.periodic(Duration(seconds: 1), (_) {
      setState(() => stopwatchSeconds++);
    });
    setState(() => isStopwatchRunning = true);
  }

  void pauseStopwatch() {
    stopwatchTimer?.cancel();
    setState(() => isStopwatchRunning = false);
  }

  void resetStopwatch() {
    stopwatchTimer?.cancel();
    setState(() {
      stopwatchSeconds = 0;
      isStopwatchRunning = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workout Tracker'),
        centerTitle: true,
        backgroundColor: Colors.yellow,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Stopwatch Section
            Column(
              children: [
                Text(
                  'Stopwatch',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                Text(
                  formatTime(stopwatchSeconds),
                  style: TextStyle(
                    fontSize: 36,
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton.icon(
                      onPressed: isStopwatchRunning ? null : startStopwatch,
                      icon: Icon(Icons.play_arrow),
                      label: Text('Start'),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton.icon(
                      onPressed: isStopwatchRunning ? pauseStopwatch : null,
                      icon: Icon(Icons.pause),
                      label: Text('Pause'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                      ),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton.icon(
                      onPressed: resetStopwatch,
                      icon: Icon(Icons.replay),
                      label: Text('Reset'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 30),

            // Workout Cards
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: workouts.length,
              itemBuilder: (context, index) {
                final workout = workouts[index];
                return Card(
                  color: workout.isCompleted ? Colors.green[50] : Colors.white,
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: ListTile(
                    title: Text(
                      workout.name,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Calories: ${workout.calories}'),
                        Text('Time Left: ${remainingTime[workout.name]}s'),
                      ],
                    ),
                    trailing: workout.isCompleted
                        ? Icon(Icons.check_circle, color: Colors.green)
                        : IconButton(
                      icon: Icon(Icons.play_circle_fill, color: Colors.blue),
                      onPressed: () => _startWorkoutTimer(workout),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
