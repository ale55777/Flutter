import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uuid/uuid.dart';
import '../models/workout.dart';

class WorkoutFormScreen extends StatefulWidget {
  final Workout? workout;
  WorkoutFormScreen({this.workout});

  @override
  State<WorkoutFormScreen> createState() => _WorkoutFormScreenState();
}

class _WorkoutFormScreenState extends State<WorkoutFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _title;
  late String _description;
  String _difficulty = 'Beginner';
  late int _duration;

  @override
  void initState() {
    super.initState();
    _title = widget.workout?.title ?? '';
    _description = widget.workout?.description ?? '';
    _difficulty = widget.workout?.difficulty ?? 'Beginner';
    _duration = widget.workout?.duration ?? 30;
  }

  void _save() {
    if (_formKey.currentState!.validate()) {
      final workout = Workout(
        id: widget.workout?.id ?? Uuid().v4(),
        title: _title,
        description: _description,
        difficulty: _difficulty,
        duration: _duration,
      );
      Navigator.pop(context, workout);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.workout == null ? 'Add Workout' : 'Edit Workout')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                initialValue: _title,
                decoration: InputDecoration(labelText: 'Title'),
                onChanged: (val) => _title = val,
                validator: (val) => val!.isEmpty ? 'Enter a title' : null,
              ),
              TextFormField(
                initialValue: _description,
                decoration: InputDecoration(labelText: 'Description'),
                onChanged: (val) => _description = val,
                validator: (val) => val!.isEmpty ? 'Enter a description' : null,
              ),
              DropdownButtonFormField<String>(
                value: _difficulty,
                decoration: InputDecoration(labelText: 'Difficulty'),
                items: ['Beginner', 'Intermediate', 'Advanced']
                    .map((e) => DropdownMenuItem(child: Text(e), value: e))
                    .toList(),
                onChanged: (val) => setState(() => _difficulty = val!),
              ),
              TextFormField(
                initialValue: _duration.toString(),
                decoration: InputDecoration(labelText: 'Duration (minutes)'),
                keyboardType: TextInputType.number,
                onChanged: (val) => _duration = int.tryParse(val) ?? 0,
                validator: (val) => (int.tryParse(val!) ?? 0) > 0 ? null : 'Enter valid duration',
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _save, child: Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
