import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/workout.dart';
import 'workout_form_screen.dart';

class WorkoutPlanScreen extends StatefulWidget {
  @override
  _WorkoutPlanScreenState createState() => _WorkoutPlanScreenState();
}

class _WorkoutPlanScreenState extends State<WorkoutPlanScreen> {
  List<Workout> _workouts = [];

  @override
  void initState() {
    super.initState();
    _loadWorkouts();
  }

  Future<void> _loadWorkouts() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('workouts');
    if (data != null) {
      final List decoded = json.decode(data);
      setState(() {
        _workouts = decoded.map((w) => Workout.fromMap(w)).toList();
      });
    }
  }

  Future<void> _saveWorkouts() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = json.encode(_workouts.map((w) => w.toMap()).toList());
    await prefs.setString('workouts', encoded);
  }

  void _addWorkout(Workout workout) {
    setState(() {
      _workouts.add(workout);
    });
    _saveWorkouts();
  }

  void _editWorkout(Workout updatedWorkout) {
    setState(() {
      final index = _workouts.indexWhere((w) => w.id == updatedWorkout.id);
      if (index != -1) {
        _workouts[index] = updatedWorkout;
      }
    });
    _saveWorkouts();
  }

  void _deleteWorkout(String id) {
    setState(() {
      _workouts.removeWhere((w) => w.id == id);
    });
    _saveWorkouts();
  }

  void _navigateToAddWorkout() async {
    final newWorkout = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => WorkoutFormScreen()),
    );
    if (newWorkout != null) _addWorkout(newWorkout);
  }

  void _navigateToEditWorkout(Workout workout) async {
    final updatedWorkout = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => WorkoutFormScreen(workout: workout)),
    );
    if (updatedWorkout != null) _editWorkout(updatedWorkout);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        title: Text('Workout Plans',
            style: GoogleFonts.roboto(
              fontSize: 22,
              color: Colors.black,
            )),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.yellow,
        onPressed: _navigateToAddWorkout,
        icon: Icon(Icons.add),
        label: Text("Add Plan", style: GoogleFonts.roboto()),
      ),
      body: _workouts.isEmpty
          ? Center(
        child: Text(
          'NO WORKOUTS YET \nAdd one!',
          textAlign: TextAlign.center,
          style: GoogleFonts.roboto(
            fontSize: 24,
            fontWeight: FontWeight.w600,
            color: Colors.deepPurple,
          ),
        ),
      )
          : ListView.builder(
        itemCount: _workouts.length,
        itemBuilder: (context, index) {
          final workout = _workouts[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 15, vertical: 8),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            elevation: 4,
            child: ListTile(
              contentPadding:
              EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              title: Text(workout.title,
                  style: GoogleFonts.roboto(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              subtitle: Text(
                "${workout.description}\n${workout.difficulty} - ${workout.duration} mins",
                style: GoogleFonts.roboto(fontSize: 14),
              ),
              isThreeLine: true,
              trailing: PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'edit') _navigateToEditWorkout(workout);
                  if (value == 'delete') _deleteWorkout(workout.id);
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'edit', child: Text('Edit')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
