class AuthService {
  static String? _registeredEmail;
  static String? _registeredPassword;

  static String? _loggedInUser;

  static bool signUp(String email, String password) {
    if (_registeredEmail != null) return false; // Already signed up
    _registeredEmail = email;
    _registeredPassword = password;
    return true;
  }

  static bool login(String email, String password) {
    if (email == _registeredEmail && password == _registeredPassword) {
      _loggedInUser = email;
      return true;
    }
    return false;
  }

  static String? get loggedInUser => _loggedInUser;

  static void logout() {
    _loggedInUser = null;
  }
}
