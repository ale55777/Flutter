import 'package:flutter/material.dart';

class PlanCard extends StatelessWidget {
  final String title;
  final String days;

  const PlanCard({
    required this.title,
    required this.days,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(Icons.fitness_center, color: Colors.blueAccent),
        title: Text(
          title,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          days,
          style: TextStyle(color: Colors.grey[600]),
        ),
        trailing: Icon(Icons.chevron_right),
        onTap: () {},
      ),
    );
  }
}
