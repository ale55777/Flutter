import 'package:flutter/material.dart';

class ExperiencePage extends StatelessWidget {
  final List<String> experience = [
    "Software Development Intern, AL-ASAR Technologies",
    "Former Web Development Intern at WEBCARE",
    "Developed a CLI Grocery Store Management System",
    "Developed a Hospital Management System",
    "MERN Stack Development",
    "X8086 Assembly Language Project",
    "Various Projects on TypeScript and JavaScript",
    "Car Rental Management System in Java",
    "Teaching Programming Fundamentals",
    "Delivered several presentations",
  ];

  @override
  Widget build(BuildContext context) {
    return _buildListPage(context, 'Experience', experience);
  }

  Widget _buildListPage(BuildContext context, String title, List<String> items) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.purpleAccent, Colors.deepPurple],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: Colors.white)),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    return Card(
                      color: Colors.white.withOpacity(0.2),
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: ListTile(
                        leading: Icon(Icons.work, color: Colors.yellowAccent),
                        title: Text(
                          items[index],
                          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
