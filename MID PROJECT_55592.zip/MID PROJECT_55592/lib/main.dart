import 'package:flutter/material.dart';
import 'skills_page.dart';
import 'education_page.dart';
import 'experience_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        textTheme: TextTheme(
          headlineLarge: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
          titleMedium: TextStyle(fontSize: 18, color: Colors.white70),
        ),
      ),
      home: AboutPage(),
    );
  }
}

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.blueAccent, Colors.purpleAccent],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            CircleAvatar(
            radius: 60,
            backgroundImage: AssetImage('assets/ali.jpg'),
          ),

              SizedBox(height: 15),
              Text('Ali Raza Khan', style: Theme.of(context).textTheme.headlineLarge),
              SizedBox(height: 10),
              Text('Front-End Developer & Graphics Designer', style: Theme.of(context).textTheme.titleMedium),
              SizedBox(height: 30),
              _buildNavButton(context, 'View Skills', SkillsPage()),
              _buildNavButton(context, 'View Education', EducationPage()),
              _buildNavButton(context, 'View Experience', ExperiencePage()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavButton(BuildContext context, String text, Widget page) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
          textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          backgroundColor: Colors.white,
          foregroundColor: Colors.deepPurple,
          elevation: 5,
        ),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => page));
        },
        child: Text(text),
      ),
    );
  }
}
