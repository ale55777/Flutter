import 'package:flutter/material.dart';

class SkillsPage extends StatelessWidget {
  final List<String> skills = ["Flutter", "React", "JavaScript", "UI/UX Design", "C++", "Next.js"];

  @override
  Widget build(BuildContext context) {
    return _buildListPage(context, 'Technical Skills', skills);
  }

  Widget _buildListPage(BuildContext context, String title, List<String> items) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.purpleAccent, Colors.deepPurple],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineLarge?.copyWith(color: Colors.white)),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    return Card(
                      color: Colors.white.withOpacity(0.2),
                      elevation: 4,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      child: ListTile(
                        leading: Icon(Icons.star, color: Colors.yellowAccent),
                        title: Text(
                          items[index],
                          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
